import React from 'react';
import NavBar from '../layout/Navbar'
const About = () => {

  return (
    <div>
    
    <NavBar/>
    <div className="container">
      <div className="py-4" className="text-black blocktext">
        <h2>About Us</h2>
        <br></br>
        <p>
          <strong>
            Vehicle Service Management System aims to be the best of both worlds
            - Reliable and Cost-effective Vehicle Services.
          </strong>
        </p>
        <p>
          Group Name:- Group:15 My Team Details :- Title - Vehicle Servicing
          Management System
        </p>
        
        <p>Member 1 - Barkha Sunil Ahuja(2022) - barkhaahuja@gmail.com</p>
        <p>Member 2 - Divyanshu Basantkumar Sahu(2041) - divyanshusahu95@gmail.com </p>
        
      </div>
    </div>
    </div>
  );
};

export default About;
