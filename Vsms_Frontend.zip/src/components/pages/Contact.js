import React from 'react';
import NavBar from '../layout/Navbar'


const Contact = () => {
  return (
    <div><NavBar/>
    <div className="container" >
      <div className="py-4" className="text-black blocktext">
        <h3>Leave us a message!</h3>
        
        <br></br>
        <h4>Helpline Numbers : 9999 999 999</h4>
        <h4>Customer Support : </h4>
        <h4>Email : info@vsms.in</h4>
      </div>
    </div>
    </div>
  );
};

export default Contact;
